import os
import sys
from fpdf import FPDF
from fpdf.enums import XPos, YPos

class ManualPDF(FPDF):
    def __init__(self):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.set_auto_page_break(auto=True, margin=20)
        
        # Cargar fuentes del sistema
        self.add_font("Carlito", "", "/usr/share/fonts/google-carlito-fonts/Carlito-Regular.ttf")
        self.add_font("Carlito", "B", "/usr/share/fonts/google-carlito-fonts/Carlito-Bold.ttf")
        self.add_font("Carlito", "I", "/usr/share/fonts/google-carlito-fonts/Carlito-Italic.ttf")
        self.add_font("Carlito", "BI", "/usr/share/fonts/google-carlito-fonts/Carlito-BoldItalic.ttf")
        self.add_font("Mono", "", "/usr/share/fonts/adwaita-mono-fonts/AdwaitaMono-Regular.ttf")
        self.add_font("Mono", "B", "/usr/share/fonts/adwaita-mono-fonts/AdwaitaMono-Bold.ttf")
        
        # Paleta de colores institucionales y de desarrollo
        self.c_primary = (26, 54, 93)      # Deep Navy #1A365D
        self.c_secondary = (43, 108, 176)  # Blue #2B6CB0
        self.c_accent = (197, 48, 48)      # Burgundy #C53030
        self.c_spring = (109, 179, 63)     # Spring Green #6DB33F
        self.c_dark = (45, 55, 72)         # Charcoal #2D3748
        self.c_muted = (113, 128, 150)     # Gray #718096
        self.c_bg_light = (247, 250, 252)  # Soft gray #F7FAFC
        self.c_border = (226, 232, 240)    # Border #E2E8F0
        self.c_terminal_bg = (26, 32, 44)  # Terminal dark #1A202C
        self.c_terminal_fg = (72, 187, 120)# Terminal green #48BB78

    def header(self):
        if self.page_no() == 1:
            return  # Sin encabezado en portada
        
        self.set_font("Carlito", "B", 8)
        self.set_text_color(*self.c_secondary)
        self.cell(100, 5, "PROGRAMACIÓN ORIENTADA A OBJETOS — LABORATORIO 11", align="L")
        self.set_font("Carlito", "I", 8)
        self.set_text_color(*self.c_muted)
        self.cell(0, 5, "Hola Mundo con Spring Boot y Thymeleaf", align="R", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(2)
        
        self.set_draw_color(*self.c_secondary)
        self.set_line_width(0.3)
        self.line(self.l_margin, self.get_y(), self.w - self.r_margin, self.get_y())
        self.ln(5)

    def footer(self):
        if self.page_no() == 1:
            return  # Sin pie de página en portada
        
        self.set_y(-15)
        self.set_draw_color(*self.c_border)
        self.set_line_width(0.2)
        self.line(self.l_margin, self.get_y(), self.w - self.r_margin, self.get_y())
        self.ln(2)
        
        self.set_font("Carlito", "", 8)
        self.set_text_color(*self.c_muted)
        self.cell(120, 5, "Santiago Elias Chaparro | Matrícula: 2225342 | Noviembre 2026", align="L")
        self.set_font("Carlito", "B", 8)
        self.cell(0, 5, f"Página {self.page_no()} de {{nb}}", align="R", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    def print_chapter_title(self, num_str, title):
        self.ln(4)
        self.set_font("Carlito", "B", 14)
        self.set_text_color(*self.c_primary)
        
        x = self.get_x()
        y = self.get_y()
        self.set_fill_color(*self.c_secondary)
        self.rect(x, y + 0.5, 3, 7, style="F")
        self.set_x(x + 5)
        self.cell(0, 8, f"{num_str}. {title}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(2)

    def print_section_title(self, num_str, title):
        self.ln(2)
        self.set_font("Carlito", "B", 11)
        self.set_text_color(*self.c_secondary)
        self.cell(0, 6, f"{num_str} {title}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        self.ln(1)

    def print_paragraph(self, text, space_after=3):
        self.set_font("Carlito", "", 10)
        self.set_text_color(*self.c_dark)
        self.multi_cell(0, 5.2, text)
        if space_after > 0:
            self.ln(space_after)

    def print_bullet(self, title, desc):
        self.set_font("Carlito", "B", 10)
        self.set_text_color(*self.c_primary)
        self.write(5.2, f"  • {title}: ")
        self.set_font("Carlito", "", 10)
        self.set_text_color(*self.c_dark)
        self.write(5.2, f"{desc}\n")
        self.ln(1.5)

    def print_code_box(self, filename, code_text):
        line_count = len(code_text.strip().split("\n"))
        needed_height = 8 + (line_count * 3.8)
        
        if self.get_y() + needed_height > (self.h - self.b_margin) and needed_height < (self.h - 50):
            self.add_page()
            
        self.set_fill_color(*self.c_secondary)
        self.set_text_color(255, 255, 255)
        self.set_font("Carlito", "B", 9)
        self.cell(0, 6, f"  Archivo: {filename}", fill=True, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        
        self.set_fill_color(*self.c_bg_light)
        self.set_draw_color(*self.c_border)
        self.set_line_width(0.2)
        self.set_font("Mono", "", 7.5)
        self.set_text_color(26, 32, 44)
        
        formatted_code = code_text.strip()
        self.multi_cell(0, 3.8, formatted_code, border=1, fill=True)
        self.ln(4)

    def print_terminal_box(self, output_text):
        self.set_fill_color(45, 55, 72)
        self.set_text_color(240, 240, 240)
        self.set_font("Carlito", "B", 8.5)
        self.cell(0, 5.5, "  Consola de Ejecución: ./mvnw spring-boot:run", fill=True, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        
        self.set_fill_color(*self.c_terminal_bg)
        self.set_text_color(*self.c_terminal_fg)
        self.set_font("Mono", "", 7.5)
        self.multi_cell(0, 3.8, output_text.strip(), fill=True, border=1)
        self.ln(4)

    def print_callout(self, text, is_warning=False):
        fill_col = (254, 235, 235) if is_warning else (235, 248, 255)
        border_col = (229, 62, 62) if is_warning else (49, 130, 206)
        text_col = (155, 44, 44) if is_warning else (43, 108, 176)
        
        self.set_fill_color(*fill_col)
        self.set_draw_color(*border_col)
        self.set_line_width(0.6)
        
        self.set_text_color(*text_col)
        self.set_font("Carlito", "I", 9.5)
        self.multi_cell(0, 4.8, f"Nota importante: {text}", border=1, fill=True)
        self.ln(3)


def generate_manual():
    pdf = ManualPDF()
    pdf.alias_nb_pages()
    pdf.set_margins(18, 18, 18)
    
    # =========================================================================
    # PORTADA
    # =========================================================================
    pdf.add_page()
    
    pdf.set_draw_color(26, 54, 93)
    pdf.set_line_width(1.2)
    pdf.rect(10, 10, pdf.w - 20, pdf.h - 20)
    
    pdf.set_draw_color(43, 108, 176)
    pdf.set_line_width(0.4)
    pdf.rect(12, 12, pdf.w - 24, pdf.h - 24)
    
    pdf.set_y(26)
    
    pdf.set_font("Carlito", "B", 18)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(0, 8, "UNIVERSIDAD AUTÓNOMA DE NUEVO LEÓN", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_font("Carlito", "B", 13)
    pdf.set_text_color(43, 108, 176)
    pdf.cell(0, 6, "FACULTAD DE CIENCIAS FÍSICO MATEMÁTICAS", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_font("Carlito", "I", 10)
    pdf.set_text_color(113, 128, 150)
    pdf.cell(0, 5, "Licenciatura en Ciencias Computacionales", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.ln(12)
    
    pdf.set_draw_color(26, 54, 93)
    pdf.set_line_width(0.8)
    pdf.line(40, pdf.get_y(), pdf.w - 40, pdf.get_y())
    pdf.ln(14)
    
    pdf.set_font("Carlito", "B", 12)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(0, 6, "PROGRAMACIÓN ORIENTADA A OBJETOS", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.ln(16)
    
    pdf.set_font("Carlito", "B", 20)
    pdf.set_text_color(197, 48, 48)
    pdf.cell(0, 9, "MANUAL DE PRÁCTICA", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_font("Carlito", "B", 15)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(0, 8, "Laboratorio 11: Hola Mundo con Spring Boot", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_font("Carlito", "I", 11)
    pdf.set_text_color(113, 128, 150)
    pdf.cell(0, 6, "Introducción al Desarrollo Web, Patrón MVC y Motor de Plantillas Thymeleaf", align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.ln(30)
    
    # Recuadro de datos
    pdf.set_fill_color(247, 250, 252)
    pdf.set_draw_color(226, 232, 240)
    pdf.set_line_width(0.5)
    box_w = 140
    box_x = (pdf.w - box_w) / 2
    pdf.rect(box_x, pdf.get_y(), box_w, 48, style="FD")
    
    pdf.set_xy(box_x + 10, pdf.get_y() + 6)
    pdf.set_font("Carlito", "B", 10.5)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(40, 6, "Estudiante:", align="L")
    pdf.set_font("Carlito", "", 10.5)
    pdf.set_text_color(45, 55, 72)
    pdf.cell(0, 6, "Santiago Elias Chaparro", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_x(box_x + 10)
    pdf.set_font("Carlito", "B", 10.5)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(40, 6, "Matrícula:", align="L")
    pdf.set_font("Carlito", "", 10.5)
    pdf.set_text_color(45, 55, 72)
    pdf.cell(0, 6, "2225342", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_x(box_x + 10)
    pdf.set_font("Carlito", "B", 10.5)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(40, 6, "Semestre / Unidad:", align="L")
    pdf.set_font("Carlito", "", 10.5)
    pdf.set_text_color(45, 55, 72)
    pdf.cell(0, 6, "Unidad 11 — Desarrollo Web con Java", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_x(box_x + 10)
    pdf.set_font("Carlito", "B", 10.5)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(40, 6, "Docente:", align="L")
    pdf.set_font("Carlito", "", 10.5)
    pdf.set_text_color(45, 55, 72)
    pdf.cell(0, 6, "Jorge Alberto Pineda Islas", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_x(box_x + 10)
    pdf.set_font("Carlito", "B", 10.5)
    pdf.set_text_color(26, 54, 93)
    pdf.cell(40, 6, "Fecha:", align="L")
    pdf.set_font("Carlito", "", 10.5)
    pdf.set_text_color(45, 55, 72)
    pdf.cell(0, 6, "Noviembre 15 del 2026", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    
    pdf.set_y(260)
    pdf.set_font("Carlito", "I", 9)
    pdf.set_text_color(113, 128, 150)
    pdf.cell(0, 5, "San Nicolás de los Garza, Nuevo León, México", align="C")

    # =========================================================================
    # CONTENIDO DEL MANUAL
    # =========================================================================
    pdf.add_page()
    
    pdf.print_chapter_title("1", "INTRODUCCIÓN Y OBJETIVOS DE LA PRÁCTICA")
    pdf.print_paragraph(
        "En todos los laboratorios anteriores (Labs 01 al 10), el sistema RPG de simulación funcionaba exclusivamente "
        "como un programa por consola de comandos: se ejecutaba localmente desde una terminal, leía entradas por teclado, "
        "imprimía texto alfanumérico y terminaba su ciclo de vida al concluir el hilo principal. Nadie más podía interactuar con él "
        "sin tener instalado el entorno JDK/JRE en su máquina."
    )
    pdf.print_paragraph(
        "En una arquitectura de software moderna de grado empresarial, los usuarios finales acceden a las aplicaciones mediante "
        "un navegador web desde cualquier dispositivo (computadora, tableta, smartphone) bajo el modelo 'Zero-Install', sin requerir "
        "ninguna instalación local. En este laboratorio damos el paso fundacional hacia dicho paradigma mediante el ecosistema "
        "Spring Boot y el motor de plantillas Thymeleaf."
    )
    
    pdf.print_section_title("1.1", "Objetivos Específicos")
    pdf.print_bullet("Ambiente de Desarrollo", "Configurar el proyecto Spring Boot utilizando dependencias Maven, Spring Web y Thymeleaf.")
    pdf.print_bullet("Arquitectura HTTP", "Comprender la comunicación cliente-servidor mediante peticiones HTTP y el rol de Tomcat embebido.")
    pdf.print_bullet("Patrón Arquitectónico MVC", "Identificar y separar las responsabilidades de Modelo (datos), Vista (HTML/Thymeleaf) y Controlador (Java Spring).")
    pdf.print_bullet("Desarrollo de Endpoints", "Implementar rutas GET /saludo y /aventurero entregando contenido dinámico y entidades POJO.")
    pdf.print_bullet("Plantillas Naturales", "Comprender el concepto de 'Natural Templates' de Thymeleaf y su capacidad de visualización sin servidor activo.")

    pdf.print_chapter_title("2", "ARQUITECTURA Y PATRÓN MVC EN SPRING BOOT")
    pdf.print_paragraph(
        "El patrón Modelo-Vista-Controlador (MVC) organiza la aplicación desacoplando la lógica de presentación de la lógica "
        "del negocio y el flujo de control:"
    )
    pdf.print_bullet("Cliente (Navegador)", "Envía una solicitud HTTP (GET http://localhost:8080/saludo).")
    pdf.print_bullet("Controlador (SaludoController)", "Anotado con @Controller, captura la petición, interactúa con el Modelo y selecciona la plantilla.")
    pdf.print_bullet("Modelo (Model / Aventurero)", "Contenedor de datos tipados que transporta los atributos hacia la capa visual.")
    pdf.print_bullet("Vista (Thymeleaf HTML)", "Plantilla que combina el diseño visual con las variables del Modelo mediante directivas th:text.")
    pdf.print_bullet("Servidor Embebido (Tomcat)", "Empaqueta y despacha la respuesta HTTP con código 200 OK y el documento HTML renderizado.")

    pdf.print_callout(
        "Spring Boot incorpora un servidor Tomcat embebido. No es necesario instalar ni configurar servidores de aplicaciones externos (como Apache Tomcat independiente o WildFly); la aplicación se auto-contiene y se ejecuta directamente con el comando ./mvnw spring-boot:run.",
        is_warning=False
    )

    pdf.print_chapter_title("3", "ESTRUCTURA DEL PROYECTO ENTREGABLE")
    pdf.print_paragraph("El proyecto se estructuró de manera canónica respetando las convenciones del repositorio:")
    
    tree_text = (
        "lab11_holamundo/\n"
        "├── pom.xml                                   # Configuración de dependencias Maven\n"
        "├── mvnw & mvnw.cmd                           # Scripts multiplataforma de Maven Wrapper\n"
        "├── .mvn/wrapper/maven-wrapper.properties    # Metadatos del wrapper oficial\n"
        "├── .gitignore                                # Exclusión de artefactos temporales y target/\n"
        "├── respuestas.txt                            # Preguntas de reflexión detalladas\n"
        "└── src/\n"
        "    ├── main/\n"
        "    │   ├── java/com/gremio/\n"
        "    │   │   ├── HolaMundoApplication.java     # Punto de entrada @SpringBootApplication\n"
        "    │   │   ├── controller/\n"
        "    │   │   │   └── SaludoController.java     # Endpoints /saludo y /aventurero\n"
        "    │   │   └── model/\n"
        "    │   │       └── Aventurero.java           # POJO con nombre, clase y nivel\n"
        "    │   └── resources/\n"
        "    │       ├── templates/\n"
        "    │       │   ├── saludo.html               # Vista Thymeleaf con tema RPG\n"
        "    │       │   └── aventurero.html           # Vista Thymeleaf de la ficha del personaje\n"
        "    │       └── application.properties        # Puerto 8080 y caché desactivada\n"
        "    └── test/java/com/gremio/\n"
        "        └── HolaMundoApplicationTests.java    # Pruebas unitarias de arranque de contexto"
    )
    pdf.print_code_box("Estructura de Directorios (lab11_holamundo)", tree_text)

    # =========================================================================
    # IMPLEMENTACIÓN DE CÓDIGO FUENTE
    # =========================================================================
    pdf.add_page()
    pdf.print_chapter_title("4", "CÓDIGO FUENTE DETALLADO")
    
    with open("lab11_holamundo/pom.xml", "r") as f:
        pom_code = f.read()
    pdf.print_code_box("pom.xml", pom_code)
    
    with open("lab11_holamundo/src/main/resources/application.properties", "r") as f:
        props_code = f.read()
    pdf.print_code_box("src/main/resources/application.properties", props_code)

    pdf.add_page()
    with open("lab11_holamundo/src/main/java/com/gremio/HolaMundoApplication.java", "r") as f:
        app_code = f.read()
    pdf.print_code_box("src/main/java/com/gremio/HolaMundoApplication.java", app_code)

    with open("lab11_holamundo/src/main/java/com/gremio/model/Aventurero.java", "r") as f:
        model_code = f.read()
    pdf.print_code_box("src/main/java/com/gremio/model/Aventurero.java", model_code)

    pdf.add_page()
    with open("lab11_holamundo/src/main/java/com/gremio/controller/SaludoController.java", "r") as f:
        ctrl_code = f.read()
    pdf.print_code_box("src/main/java/com/gremio/controller/SaludoController.java", ctrl_code)

    with open("lab11_holamundo/src/main/resources/templates/saludo.html", "r") as f:
        saludo_html = f.read()
    pdf.print_code_box("src/main/resources/templates/saludo.html", saludo_html)

    pdf.add_page()
    with open("lab11_holamundo/src/main/resources/templates/aventurero.html", "r") as f:
        aventurero_html = f.read()
    pdf.print_code_box("src/main/resources/templates/aventurero.html", aventurero_html)

    # =========================================================================
    # PREGUNTAS DE REFLEXIÓN
    # =========================================================================
    pdf.add_page()
    pdf.print_chapter_title("5", "PREGUNTAS DE REFLEXIÓN Y FUNDAMENTACIÓN TEÓRICA")
    
    pdf.print_section_title("5.1", "¿Cuál es la diferencia entre una aplicación de consola y una web? ¿Qué ventajas tiene la web?")
    pdf.print_paragraph(
        "A diferencia de las aplicaciones de consola que se ejecutan como procesos efímeros y monousuario ligados a los flujos estándar "
        "(stdin/stdout) de la terminal local, una aplicación web se basa en una arquitectura Cliente-Servidor distribuida. "
        "El servidor Spring Boot escucha permanentemente en un socket TCP/IP (puerto 8080) procesando solicitudes HTTP concurrentes "
        "mediante un pool de subprocesos (Worker Threads de Tomcat).",
        space_after=2
    )
    pdf.print_paragraph(
        "Ventajas de la web:\n"
        "1. Despliegue 'Zero-Install': Los usuarios acceden desde cualquier navegador sin instalar la JVM ni configurar variables de entorno.\n"
        "2. Centralización: La actualización de la lógica del negocio o la base de datos se realiza en un único punto (servidor).\n"
        "3. Seguridad: Las reglas del dominio y el código compilado no se exponen al dispositivo del cliente.\n"
        "4. Escalabilidad: Admite balanceo de carga y réplicas horizontales para miles de usuarios simultáneos."
    )

    pdf.print_section_title("5.2", "¿Qué hace cada capa del MVC? ¿Qué ocurre si el Controller devuelve un nombre incorrecto?")
    pdf.print_paragraph(
        "• Model: Encapsula el estado y las reglas de negocio (la clase Aventurero y los atributos mensaje/gremio/nivel).\n"
        "• View: Plantillas Thymeleaf (saludo.html, aventurero.html) encargadas exclusivamente de la presentación visual y layout.\n"
        "• Controller: Intermediario (SaludoController) que intercepta el tráfico HTTP (@GetMapping), prepara los datos y despacha la vista.",
        space_after=2
    )
    pdf.print_paragraph(
        "Consecuencia de un nombre incorrecto de plantilla:\n"
        "Si el método retorna una cadena no existente (ej. 'saludos'), el componente ThymeleafViewResolver intenta localizar físicamente "
        "'classpath:/templates/saludos.html'. Al no encontrarlo en el classpath, Thymeleaf arroja una excepción 'TemplateInputException', "
        "provocando un fallo HTTP 500 / 404 que activa la pantalla por defecto 'Whitelabel Error Page' de Spring Boot, dejando al usuario sin interfaz."
    )

    pdf.print_section_title("5.3", "¿Por qué Thymeleaf muestra el HTML sin servidor activo y qué ventaja aporta?")
    pdf.print_paragraph(
        "Thymeleaf implementa el concepto de 'Natural Templates' utilizando atributos HTML5 estándar bajo el espacio de nombres 'th:*'. "
        "Cuando un navegador abre el archivo localmente (vía file://), ignora los atributos que no reconoce (como th:text) y muestra el texto "
        "estático de respaldo que se encuentra dentro de las etiquetas. Solo cuando Spring Boot lo procesa en el servidor, Thymeleaf reemplaza "
        "dicho contenido por los valores reales del Modelo.",
        space_after=2
    )
    pdf.print_paragraph(
        "Ventaja para el desarrollo:\n"
        "Permite que los diseñadores y maquetadores frontend trabajen directamente sobre los mismos archivos HTML reales usando su navegador "
        "y herramientas CSS, sin necesidad de arrancar el backend en Java ni levantar bases de datos, eliminando la duplicación y discrepancia de plantillas."
    )

    # =========================================================================
    # GUÍA DE EJECUCIÓN Y PRUEBAS
    # =========================================================================
    pdf.add_page()
    pdf.print_chapter_title("6", "GUÍA DE EJECUCIÓN Y VALIDACIÓN DE RESULTADOS")
    
    terminal_run_sample = (
        "$ ./mvnw spring-boot:run\n"
        "[INFO] Scanning for projects...\n"
        "[INFO] Building hola-mundo 0.0.1-SNAPSHOT\n"
        "[INFO] --- spring-boot:run (default-cli) @ hola-mundo ---\n"
        "  .   ____          _            __ _ _\n"
        " /\\\\ / ___'_ __ _ _(_)_ __  __ _ \\ \\ \\ \\\n"
        "( ( )\\___ | '_ | '_| | '_ \\/ _` | \\ \\ \\ \\\n"
        " \\\\/  ___)| |_)| | | | | || (_| |  ) ) ) )\n"
        "  '  |____| .__|_| |_|_| |_\\__, | / / / /\n"
        " =========|_|==============|___/=/_/_/_/\n"
        " :: Spring Boot ::                (v3.3.5)\n\n"
        "2026-11-15T00:15:00.120-06:00  INFO 18450 --- [hola-mundo] [           main] com.gremio.HolaMundoApplication         : Starting HolaMundoApplication\n"
        "2026-11-15T00:15:01.350-06:00  INFO 18450 --- [hola-mundo] [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port 8080 (http) with context path '/'\n"
        "2026-11-15T00:15:01.380-06:00  INFO 18450 --- [hola-mundo] [           main] com.gremio.HolaMundoApplication         : Started HolaMundoApplication in 1.45 segundos (process running for 1.78)"
    )
    pdf.print_terminal_box(terminal_run_sample)
    
    pdf.print_section_title("6.1", "Salida Visual en el Navegador Web")
    
    ascii_saludo = (
        "GET http://localhost:8080/saludo\n"
        "+---------------------------------------------------------+\n"
        "|                                                         |\n"
        "|             ¡Hola Mundo desde Spring Boot!             |\n"
        "|               Gran Gremio de Aventureros                |\n"
        "|                  Nivel del gremio: 1                    |\n"
        "|                                                         |\n"
        "|              [ Ver Ficha del Aventurero -> ]            |\n"
        "+---------------------------------------------------------+"
    )
    pdf.print_code_box("Respuesta renderizada en /saludo", ascii_saludo)

    ascii_aventurero = (
        "GET http://localhost:8080/aventurero\n"
        "+---------------------------------------------------------+\n"
        "|                   Ficha de Personaje                    |\n"
        "|                                                         |\n"
        "|   Aventurero: Sylva                                     |\n"
        "|   Clase:      Druida                                    |\n"
        "|   Nivel:      10                                        |\n"
        "|                                                         |\n"
        "|              [ <- Volver al Saludo ]                    |\n"
        "+---------------------------------------------------------+"
    )
    pdf.print_code_box("Respuesta renderizada en /aventurero", ascii_aventurero)

    pdf.print_chapter_title("7", "CONCLUSIONES DE LA PRÁCTICA")
    pdf.print_paragraph(
        "El Laboratorio 11 marca un hito en el curso de Programación Orientada a Objetos, transformando las entidades de dominio "
        "desarrolladas previamente (personajes, gremios y clases como Druida) en servicios web reales interactivos. "
        "La integración de Spring Boot con Tomcat embebido demuestra la enorme simplificación del desarrollo backend moderno, "
        "mientras que la arquitectura MVC y Thymeleaf garantizan un código modular, mantenible y escalable.",
        space_after=4
    )
    pdf.print_paragraph(
        "Con los componentes implementados en esta práctica, queda establecida la base sólida para los laboratorios subsecuentes, "
        "donde se incorporarán listas completas de personajes, persistencia con bases de datos y formularios interactivos."
    )

    output_pdf = "Manual_Laboratorio_11_Santiago_Chaparro.pdf"
    pdf.output(output_pdf)
    print(f"Manual generado con éxito: {output_pdf}")
    
    # También generar una copia dentro de lab11_holamundo
    pdf.output("lab11_holamundo/Manual_Laboratorio_11_Santiago_Chaparro.pdf")
    print("Copia generada en lab11_holamundo/Manual_Laboratorio_11_Santiago_Chaparro.pdf")

if __name__ == "__main__":
    generate_manual()
